import requests
import json
import base64

# Thông tin API UAT
USERNAME = "simo-busanhcm"
PASSWORD = "simo660"
CONSUMER_KEY = "V2sF9dfIfbqXAkBfyauNz9WTJQoa"
CONSUMER_SECRET = "lnr90QpFPfClcm1chY5wijrLH08a"
TOKEN_URL = "https://mgsimotest.sbv.gov.vn/token"
ENTRYPOINT_URL = "https://mgsimotest.sbv.gov.vn/simo/tktt/1.0/upload-bao-cao-tktt-nngl-api" #  Gui moi danh sach tai khoan nghi ngon gian lan ( GUi lan Đầu )

# Hàm lấy token
def get_sbv_token():
    try:
        auth_string = f"{CONSUMER_KEY}:{CONSUMER_SECRET}"
        auth_base64 = base64.b64encode(auth_string.encode("utf-8")).decode("utf-8")
        headers = {
            "Authorization": f"Basic {auth_base64}",
            "Content-Type": "application/x-www-form-urlencoded"
        }
        data = {
            "grant_type": "password",
            "username": USERNAME,
            "password": PASSWORD
        }
        response = requests.post(TOKEN_URL, headers=headers, data=data, timeout=10)
        response.raise_for_status()
        return response.json().get("access_token")
    except requests.RequestException as e:
        print(f"[❌] Lỗi khi lấy token: {e}")
        return None

# Hàm gửi dữ liệu TKTT
def send_simo_001_data():
    token = get_sbv_token()
    if not token:
        print("[❌] Không thể lấy token, dừng chương trình.")
        return

    # Điền cứng maYeuCau và kyBaoCao trong header
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "maYeuCau": "simo003_TKTT_032024", #Simo 003 Gửi lần đầu DS Tài khoảng thanh toán nghia ngờ gian lận
        "kyBaoCao": "03/2024"
    }
    
    payload = [
    {
            "Cif": "111222333",
            "SoTaiKhoan": "070987654321",
            "TenKhachHang": "Pham Phuong Trinh A",
            "TrangThaiHoatDongTaiKhoan": 3,  #1.Đang hoạt động; 2.Tạm ngừng cung cấp dịch vụ ngân hàng điện tử; 3.Tạm khóa; 4.Phong tỏa; 5.Đã đóng.
            "NghiNgo":7,
            "GhiChu": "" # string Max 5000
            #Cot nghi ngo interger tu 0 den 7 xem DOCS
    }
]
    # Không dùng query parameter, chỉ gửi qua header
    url = ENTRYPOINT_URL

    try:
        print(f"[📌] Header gửi đi: {headers}")
        print("[📌] Dữ liệu JSON gửi đi:")
        print(json.dumps(payload, indent=4, ensure_ascii=False))
        response = requests.post(url, headers=headers, json=payload, timeout=10)
        response.raise_for_status()
        print("[✔] Dữ liệu gửi thành công:", response.json())
    except requests.RequestException as e:
        print(f"[❌] Lỗi khi gửi dữ liệu: {e}")
        if e.response is not None:
            print(f"[❌] Chi tiết lỗi từ server: {e.response.text}")

# Chạy test
if __name__ == "__main__":
    send_simo_001_data()
