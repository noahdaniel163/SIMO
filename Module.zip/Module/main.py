# get_token.py
import os
from auth import get_sbv_token

def save_token_to_file(token, file_path):
    """
    Lưu token vào file txt.
    :param token: Token cần lưu.
    :param file_path: Đường dẫn file để lưu token.
    """
    try:
        with open(file_path, "w", encoding="utf-8") as file:
            file.write(token)
        print(f"[✔] Token đã được lưu vào file: {file_path}")
    except Exception as e:
        print(f"[❌] Lỗi khi lưu token vào file: {e}")

def main():
    # Lấy token và expires_in từ API
    token, expires_in = get_sbv_token()
    
    # Kiểm tra xem token có tồn tại không
    if not token:
        print("[❌] Không thể lấy token, dừng chương trình.")
        return

    # Kiểm tra thời gian hết hạn (nếu có)
    if expires_in is not None:
        print(f"[ℹ] Token sẽ hết hạn sau {expires_in} giây.")
    else:
        print("[ℹ] Token không có thông tin thời gian hết hạn.")

    # Đường dẫn file để lưu token (ổ C:)
    file_path = r"C:\token.txt"

    # Lưu token vào file
    save_token_to_file(token, file_path)

if __name__ == "__main__":
    main()