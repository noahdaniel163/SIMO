# api.py
import requests
import json
from auth import get_sbv_token
from config import ENTRYPOINT_URL

def send_simo_001_data(payload):
    token = get_sbv_token()
    if not token:
        print("[❌] Không thể lấy token, dừng chương trình.")
        return

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "maYeuCau": "TKTT_032024",
        "kyBaoCao": "03/2024"
    }

    url = ENTRYPOINT_URL

    try:
        print(f"[📌] Header gửi đi: {headers}")
        print("[📌] Dữ liệu JSON gửi đi:")
        print(json.dumps(payload, indent=4, ensure_ascii=False))
        response = requests.post(url, headers=headers, json=payload, timeout=10)
        response.raise_for_status()
        print("[✔] Dữ liệu gửi thành công:", response.json())
    except requests.RequestException as e:
        print(f"[❌] Lỗi khi gửi dữ liệu: {e}")
        if e.response is not None:
            print(f"[❌] Chi tiết lỗi từ server: {e.response.text}")