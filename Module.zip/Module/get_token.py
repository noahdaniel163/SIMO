# get_token.py
import requests
import base64
import logging
import pyodbc
from datetime import datetime
from config import USERNAME, PASSWORD, CONSUMER_KEY, CONSUMER_SECRET, TOKEN_URL

# Cấu hình logging
logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")

# Thông tin kết nối database
DB_SERVER = "10.8.103.21"
DB_DATABASE = "test"
DB_USER = "sa"
DB_PASSWORD = "q"
DB_TABLE = "api_tokens"

def get_sbv_token():
    """
    Lấy token từ API của SBV.
    Trả về token và thời gian hết hạn (expires_in) nếu có.
    """
    try:
        # Tạo chuỗi auth và mã hóa base64
        auth_string = f"{CONSUMER_KEY}:{CONSUMER_SECRET}"
        auth_base64 = base64.b64encode(auth_string.encode("utf-8")).decode("utf-8")

        # Header và body của request
        headers = {
            "Authorization": f"Basic {auth_base64}",
            "Content-Type": "application/x-www-form-urlencoded"
        }
        data = {
            "grant_type": "password",
            "username": USERNAME,
            "password": PASSWORD
        }

        # Gửi request lấy token
        logging.info("Đang gửi yêu cầu lấy token...")
        response = requests.post(TOKEN_URL, headers=headers, data=data, timeout=10)
        response.raise_for_status()  # Kiểm tra lỗi HTTP

        # Parse JSON response
        token_data = response.json()
        logging.info(f"Phản hồi từ API: {token_data}")  # Log toàn bộ phản hồi từ API

        access_token = token_data.get("access_token")
        token_type = token_data.get("token_type")
        expires_in = token_data.get("expires_in")
        refresh_token = token_data.get("refresh_token")
        created_at = datetime.now()  # Thời gian hiện tại

        if not access_token:
            logging.error("Không nhận được token từ API.")
            return None, None, None, None, None

        logging.info(f"Token đã được lấy thành công. Thời gian hết hạn: {expires_in} giây.")
        return access_token, token_type, expires_in, created_at, refresh_token

    except requests.RequestException as e:
        logging.error(f"Lỗi khi lấy token: {e}")
        return None, None, None, None, None

def save_token_to_db(access_token, token_type, expires_in, created_at, refresh_token):
    """
    Lưu token vào database MS SQL.
    """
    connection = None  # Khởi tạo biến connection trước
    try:
        # Chuỗi kết nối đến MS SQL Server
        connection_string = (
            f"DRIVER={{ODBC Driver 17 for SQL Server}};"
            f"SERVER={DB_SERVER};"
            f"DATABASE={DB_DATABASE};"
            f"UID={DB_USER};"
            f"PWD={DB_PASSWORD};"
        )

        # Kết nối đến database
        connection = pyodbc.connect(connection_string)
        cursor = connection.cursor()

        # Tạo câu lệnh SQL để chèn dữ liệu
        sql = f"""
        INSERT INTO {DB_TABLE} (access_token, token_type, expires_in, created_at, refresh_token)
        VALUES (?, ?, ?, ?, ?)
        """

        # Thực thi câu lệnh SQL
        cursor.execute(sql, (access_token, token_type, expires_in, created_at, refresh_token))
        connection.commit()  # Lưu thay đổi

        logging.info("Token đã được lưu vào database thành công.")

    except pyodbc.Error as e:
        logging.error(f"Lỗi khi lưu token vào database: {e}")
    finally:
        if connection:  # Kiểm tra xem connection có tồn tại không
            connection.close()  # Đóng kết nối

def main():
    # Lấy token và thông tin liên quan
    access_token, token_type, expires_in, created_at, refresh_token = get_sbv_token()
    if not access_token:
        logging.error("Không thể lấy token, dừng chương trình.")
        return

    # Lưu token vào database
    save_token_to_db(access_token, token_type, expires_in, created_at, refresh_token)

if __name__ == "__main__":
    main()
