import requests
import json
import base64
import pyodbc
from datetime import datetime, timedelta
import os

# Thông tin API UAT
USERNAME = "simo-busanhcm"
PASSWORD = "simo660"
CONSUMER_KEY = "V2sF9dfIfbqXAkBfyauNz9WTJQoa"
CONSUMER_SECRET = "lnr90QpFPfClcm1chY5wijrLH08a"
TOKEN_URL = "https://mgsimotest.sbv.gov.vn/token"
ENTRYPOINT_URL = "https://mgsimotest.sbv.gov.vn/simo/tktt/1.0/upload-bao-cao-danh-sach-tktt-api"

# Thông tin kết nối database (MS SQL Server)
DB_CONFIG = {
    "server": "10.8.103.21",
    "user": "sa",
    "password": "q",
    "database": "simo"  
}

# Đường dẫn file log
LOG_FILE = "api_response_log.txt"

# Hàm ghi log vào file
def write_to_log(message):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"[{timestamp}] {message}\n"
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(log_entry)

# Hàm kết nối database
def connect_to_db():
    try:
        conn_str = (
            f"DRIVER={{ODBC Driver 17 for SQL Server}};"
            f"SERVER={DB_CONFIG['server']};"
            f"DATABASE={DB_CONFIG['database']};"
            f"UID={DB_CONFIG['user']};"
            f"PWD={DB_CONFIG['password']}"
        )
        connection = pyodbc.connect(conn_str)
        return connection
    except Exception as e:
        write_to_log(f"[❌] Lỗi khi kết nối database: {e}")
        return None

# Hàm lấy token từ API
def get_sbv_token(refresh=False, refresh_token=None):
    try:
        auth_string = f"{CONSUMER_KEY}:{CONSUMER_SECRET}"
        auth_base64 = base64.b64encode(auth_string.encode("utf-8")).decode("utf-8")
        headers = {
            "Authorization": f"Basic {auth_base64}",
            "Content-Type": "application/x-www-form-urlencoded"
        }
        if refresh and refresh_token:
            # Dữ liệu đầu vào cho refresh token theo mô tả API
            data = {
                "grant_type": "refresh_token",
                "refresh_token": refresh_token
            }
        else:
            # Dữ liệu đầu vào để lấy token mới
            data = {
                "grant_type": "password",
                "username": USERNAME,
                "password": PASSWORD
            }
        response = requests.post(TOKEN_URL, headers=headers, data=data, timeout=10)
        response.raise_for_status()
        token_data = response.json()
        return token_data
    except requests.RequestException as e:
        write_to_log(f"[❌] Lỗi khi lấy token: {e}")
        return None

# Hàm kiểm tra và lấy token từ bảng api_tokens
def check_and_get_token():
    connection = connect_to_db()
    if not connection:
        return None

    try:
        cursor = connection.cursor()
        # Lấy token mới nhất từ bảng api_tokens
        query = """
        SELECT TOP 1 access_token, token_type, expires_in, created_at, refresh_token
        FROM api_tokens
        ORDER BY created_at DESC
        """
        cursor.execute(query)
        row = cursor.fetchone()

        if row:
            access_token, token_type, expires_in, created_at, refresh_token = row
            # Tính thời gian hết hạn
            expires_at = created_at + timedelta(seconds=expires_in)
            current_time = datetime.now()

            if current_time < expires_at:
                # Token còn hạn, sử dụng token hiện tại
                write_to_log("[ℹ] Token còn hạn, sử dụng token hiện tại.")
                cursor.close()
                connection.close()
                return access_token
            else:
                # Token hết hạn, thử refresh token
                write_to_log("[ℹ] Token hết hạn, tiến hành refresh token.")
                token_data = get_sbv_token(refresh=True, refresh_token=refresh_token)
                if token_data:
                    # Refresh token thành công, lấy các trường từ response API
                    new_access_token = token_data.get("access_token")
                    new_token_type = token_data.get("token_type")
                    new_expires_in = token_data.get("expires_in")
                    new_scope = token_data.get("scope", "")  # scope có thể không có
                    created_at = datetime.now()

                    # Lưu token mới vào bảng api_tokens
                    # Bảng api_tokens không có cột scope, nên không lưu trường này
                    insert_query = """
                    INSERT INTO api_tokens (access_token, token_type, expires_in, created_at, refresh_token)
                    VALUES (?, ?, ?, ?, ?)
                    """
                    # API refresh token không trả về refresh_token mới, giữ nguyên refresh_token cũ
                    cursor.execute(insert_query, (new_access_token, new_token_type, new_expires_in, created_at, refresh_token))
                    connection.commit()
                    write_to_log("[✔] Refresh token thành công và lưu vào database.")
                    cursor.close()
                    connection.close()
                    return new_access_token
                else:
                    # Refresh token thất bại, lấy token mới
                    write_to_log("[❌] Refresh token thất bại, tiến hành lấy token mới.")
                    token_data = get_sbv_token(refresh=False)
                    if token_data:
                        new_access_token = token_data.get("access_token")
                        new_token_type = token_data.get("token_type")
                        new_expires_in = token_data.get("expires_in")
                        new_refresh_token = token_data.get("refresh_token")
                        created_at = datetime.now()

                        # Lưu token mới vào bảng api_tokens
                        insert_query = """
                        INSERT INTO api_tokens (access_token, token_type, expires_in, created_at, refresh_token)
                        VALUES (?, ?, ?, ?, ?)
                        """
                        cursor.execute(insert_query, (new_access_token, new_token_type, new_expires_in, created_at, new_refresh_token))
                        connection.commit()
                        write_to_log("[✔] Lấy token mới thành công và lưu vào database.")
                        cursor.close()
                        connection.close()
                        return new_access_token
                    else:
                        write_to_log("[❌] Không thể lấy token mới.")
                        cursor.close()
                        connection.close()
                        return None
        else:
            # Không có token trong bảng, lấy token mới
            write_to_log("[ℹ] Không tìm thấy token trong database, lấy token mới.")
            token_data = get_sbv_token(refresh=False)
            if token_data:
                access_token = token_data.get("access_token")
                token_type = token_data.get("token_type")
                expires_in = token_data.get("expires_in")
                refresh_token = token_data.get("refresh_token")
                created_at = datetime.now()

                # Lưu token mới vào bảng api_tokens
                insert_query = """
                INSERT INTO api_tokens (access_token, token_type, expires_in, created_at, refresh_token)
                VALUES (?, ?, ?, ?, ?)
                """
                cursor.execute(insert_query, (access_token, token_type, expires_in, created_at, refresh_token))
                connection.commit()
                write_to_log("[✔] Lấy token mới thành công và lưu vào database.")
                cursor.close()
                connection.close()
                return access_token
            else:
                write_to_log("[❌] Không thể lấy token mới.")
                cursor.close()
                connection.close()
                return None

    except Exception as e:
        write_to_log(f"[❌] Lỗi khi kiểm tra token trong database: {e}")
        cursor.close()
        connection.close()
        return None

# Hàm lấy dữ liệu từ database dựa trên danh sách CIF
def get_data_from_db(cif_list=None):
    try:
        connection = connect_to_db()
        if not connection:
            return []

        cursor = connection.cursor()

        if not cif_list:
            current_date = datetime.now()
            current_month = current_date.month
            current_year = current_date.year

            query = """
            SELECT SoCIF, SoID, LoaiID, TenKhachHang, NgaySinh, GioiTinh, QuocTich, MaSoThue, 
                   SoDienThoaiDangKyDichVu, DiaChi, DiaChiKiemSoatTruyCap, MaSoNhanDangThietBiDiDong, 
                   SoTaiKhoan, LoaiTaiKhoan, TrangThaiHoatDongTaiKhoan, NgayMoTaiKhoan, 
                   PhuongThucMoTaiKhoan, NgayXacThucTaiQuay, CreatedAt
            FROM DanhSachTKTT
            WHERE MONTH(CreatedAt) = ? AND YEAR(CreatedAt) = ?
            """
            cursor.execute(query, (current_month, current_year))
        else:
            cif_tuple = tuple(cif_list)
            placeholders = ','.join('?' * len(cif_tuple))
            query = f"""
            SELECT SoCIF, SoID, LoaiID, TenKhachHang, NgaySinh, GioiTinh, QuocTich, MaSoThue, 
                   SoDienThoaiDangKyDichVu, DiaChi, DiaChiKiemSoatTruyCap, MaSoNhanDangThietBiDiDong, 
                   SoTaiKhoan, LoaiTaiKhoan, TrangThaiHoatDongTaiKhoan, NgayMoTaiKhoan, 
                   PhuongThucMoTaiKhoan, NgayXacThucTaiQuay, CreatedAt
            FROM DanhSachTKTT
            WHERE SoCIF IN ({placeholders})
            """
            cursor.execute(query, cif_tuple)

        rows = cursor.fetchall()
        write_to_log(f"[ℹ] Số bản ghi tìm thấy trong database: {len(rows)}")
        for row in rows:
            write_to_log(f"[ℹ] Bản ghi từ DB - SoCIF: {row[0]}, MaSoThue: {row[7]}")

        payload = []
        for row in rows:
            record = {
                "Cif": row[0],
                "SoID": row[1],
                "LoaiID": row[2],
                "TenKhachHang": row[3],
                "NgaySinh": row[4],
                "GioiTinh": row[5],
                "SoDienThoaiDangKyDichVu": row[8],
                "DiaChi": row[9],
                "DiaChiKiemSoatTruyCap": row[10],
                "MaSoNhanDangThietBiDiDong": row[11],
                "LoaiTaiKhoan": row[13],
                "TrangThaiHoatDongTaiKhoan": row[14],
                "NgayMoTaiKhoan": row[15],
                "PhuongThucMoTaiKhoan": row[16],
                "NgayXacThucTaiQuay": row[17],
                "QuocTich": row[6]
            }

            ma_so_thue = str(row[7]) if row[7] is not None else "0"
            if ma_so_thue != "0" and len(ma_so_thue) in [10, 13]:
                record["MaSoThue"] = int(ma_so_thue)
            
            so_tai_khoan_raw = str(row[12]) if row[12] is not None else "0"
            try:
                so_tai_khoan = int(so_tai_khoan_raw)
            except ValueError:
                so_tai_khoan = 0
            record["SoTaiKhoan"] = so_tai_khoan

            payload.append(record)
            write_to_log(f"[ℹ] Thêm bản ghi vào payload - SoCIF: {row[0]}, MaSoThue: {ma_so_thue}")

        cursor.close()
        connection.close()
        write_to_log(f"[ℹ] Số bản ghi trong payload: {len(payload)}")
        return payload

    except Exception as e:
        write_to_log(f"[❌] Lỗi khi lấy dữ liệu từ database: {e}")
        return []

# Hàm gửi dữ liệu TKTT
def send_simo_001_data(cif_list=None):
    token = check_and_get_token()
    if not token:
        write_to_log("[❌] Không thể lấy token, dừng chương trình.")
        return

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "maYeuCau": "simo001_TKTT_032024",
        "kyBaoCao": "03/2024"
    }

    payload = get_data_from_db(cif_list)

    if not payload:
        write_to_log("[❌] Không có dữ liệu nào để gửi.")
        return

    url = ENTRYPOINT_URL

    try:
        write_to_log(f"[📌] Header gửi đi: {headers}")
        write_to_log("[📌] Dữ liệu JSON gửi đi:")
        write_to_log(json.dumps(payload, indent=4, ensure_ascii=False))
        response = requests.post(url, headers=headers, json=payload, timeout=10)
        response.raise_for_status()
        response_data = response.json()
        write_to_log("[✔] Dữ liệu gửi thành công:")
        write_to_log(json.dumps(response_data, indent=4, ensure_ascii=False))
    except requests.RequestException as e:
        write_to_log(f"[❌] Lỗi khi gửi dữ liệu: {e}")
        if e.response is not None:
            write_to_log(f"[❌] Chi tiết lỗi từ server: {e.response.text}")

# Hàm chính để chạy chương trình
def main():
    cif_input = input("Nhập số CIF (cách nhau bởi dấu phẩy nếu nhiều CIF, để trống để gửi tất cả): ").strip()
    
    if cif_input:
        cif_list = [cif.strip() for cif in cif_input.split(",") if cif.strip()]
        if cif_list:
            write_to_log(f"[ℹ] Gửi dữ liệu cho các CIF: {cif_list}")
            send_simo_001_data(cif_list)
        else:
            write_to_log("[❌] Danh sách CIF không hợp lệ.")
    else:
        write_to_log("[ℹ] Không nhập CIF, gửi tất cả dữ liệu trong tháng hiện tại.")
        send_simo_001_data()

# Chạy chương trình
if __name__ == "__main__":
    main()