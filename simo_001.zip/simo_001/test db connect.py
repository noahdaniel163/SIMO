import pymysql

def check_database_connection():
    try:
        # Tạo kết nối đến database
        connection = pymysql.connect(
            host='10.8.103.21',    # Thay localhost bằng host của bạn nếu cần
            user='sa',
            password='q',
            database='simo',
            charset='utf8mb4',
            cursorclass=pymysql.cursors.DictCursor
        )
        print("Kết nối đến database thành công!")
        
        # Tạo cursor
        with connection.cursor() as cursor:
            # Thử select dòng đầu tiên từ table DanhSachTKTT
            query = "SELECT * FROM DanhSachTKTT LIMIT 1"
            cursor.execute(query)
            
            # Lấy kết quả
            row = cursor.fetchone()
            
            if row:
                print("Dòng đầu tiên trong table DanhSachTKTT:")
                # In ra tất cả các cột của dòng
                for key, value in row.items():
                    print(f"{key}: {value}")
            else:
                print("Table DanhSachTKTT không có dữ liệu!")
                
    except pymysql.Error as e:
        print("Lỗi khi kết nối hoặc truy vấn database:")
        print(str(e))
        
    finally:
        # Đóng kết nối nếu đã mở
        if 'connection' in locals():
            connection.close()
            print("Đã đóng kết nối database.")

# Gọi hàm để kiểm tra
if __name__ == "__main__":
    check_database_connection()