import requests
import json
import base64

# Thông tin API UAT
USERNAME = "simo-busanhcm"
PASSWORD = "simo660"
CONSUMER_KEY = "V2sF9dfIfbqXAkBfyauNz9WTJQoa"
CONSUMER_SECRET = "lnr90QpFPfClcm1chY5wijrLH08a"
TOKEN_URL = "https://mgsimotest.sbv.gov.vn/token"
ENTRYPOINT_URL = "https://mgsimotest.sbv.gov.vn/simo/tktt/1.0/upload-bao-cao-danh-sach-tktt-api" # tai khoan moi

# Hàm lấy token
def get_sbv_token():
    try:
        auth_string = f"{CONSUMER_KEY}:{CONSUMER_SECRET}"
        auth_base64 = base64.b64encode(auth_string.encode("utf-8")).decode("utf-8")
        headers = {
            "Authorization": f"Basic {auth_base64}",
            "Content-Type": "application/x-www-form-urlencoded"
        }
        data = {
            "grant_type": "password",
            "username": USERNAME,
            "password": PASSWORD
        }
        response = requests.post(TOKEN_URL, headers=headers, data=data, timeout=10)
        response.raise_for_status()
        return response.json().get("access_token")
    except requests.RequestException as e:
        print(f"[❌] Lỗi khi lấy token: {e}")
        return None

# Hàm gửi dữ liệu TKTT
def send_simo_001_data():
    token = get_sbv_token()
    if not token:
        print("[❌] Không thể lấy token, dừng chương trình.")
        return

    # Điền cứng maYeuCau và kyBaoCao trong header
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "maYeuCau": "simo001_TKTT_032024",
        "kyBaoCao": "03/2024"
    }
    
    payload = [
    {
        "Cif": "111222333",
        "SoID": "070987654321",  # Max 15 ký tự
        "LoaiID": 1,  # 1: Thẻ căn cước, 4: Hộ chiếu, 7: Giấy tờ khác
        "TenKhachHang": "Pham Phuong Trinh A",
        "NgaySinh": "12/02/1992",  # Định dạng DD/MM/YYYY
        "GioiTinh": 0,  # Nữ 0, Nam 1, LGBT ko ghi
        "MaSoThue": "9876543210",
        "SoDienThoaiDangKyDichVu": "0967123456",  # 15 ký tự, 0 nếu không thu thập
        "DiaChi": "100 Đường ABC, Quận 1, TP. Hồ Chí Minh",
        "DiaChiKiemSoatTruyCap": "22:33:44:55:66:77",  # MAC Address giả lập
        "MaSoNhanDangThietBiDiDong": "123456789876543",  # IMEI giả lập
        "SoTaiKhoan": "1111222233334444555",
        "LoaiTaiKhoan": 1,  # USD 2, VND 1
        "TrangThaiHoatDongTaiKhoan": 1,  # Mở tại quầy 1, eKYC 2
        "NgayMoTaiKhoan": "05/06/2021",
        "PhuongThucMoTaiKhoan": 2,
        "NgayXacThucTaiQuay": "05/06/2021",  # Định dạng DD/MM/YYYY
        "QuocTich": "VietNam"
    },
    {
        "Cif": "444555666",
        "SoID": "080567890123",  # Max 15 ký tự
        "LoaiID": 4,  # Hộ chiếu
        "TenKhachHang": "Pham Phuong Trinh B",
        "NgaySinh": "25/07/1987",  # Định dạng DD/MM/YYYY
        "GioiTinh": 1,  # Nam
        "MaSoThue": "1122334455",
        "SoDienThoaiDangKyDichVu": "0987654321",  # Số điện thoại hợp lệ
        "DiaChi": "200 Đường DEF, Quận 3, TP. Hà Nội",
        "DiaChiKiemSoatTruyCap": "AA:BB:CC:DD:EE:FF",  # MAC Address giả lập
        "MaSoNhanDangThietBiDiDong": "998877665544332",  # IMEI giả lập
        "SoTaiKhoan": "6666777788889999000",
        "LoaiTaiKhoan": 2,  # USD
        "TrangThaiHoatDongTaiKhoan": 2,  # eKYC
        "NgayMoTaiKhoan": "15/09/2020",
        "PhuongThucMoTaiKhoan": 2,
        "NgayXacThucTaiQuay": "15/09/2020",  # Định dạng DD/MM/YYYY
        "QuocTich": "VietNam"
    },
    {
        "Cif": "777888999",
        "SoID": "090345678901",  # Max 15 ký tự
        "LoaiID": 7,  # Giấy tờ khác
        "TenKhachHang": "Pham Phuong Trinh C",
        "NgaySinh": "30/11/1995",  # Định dạng DD/MM/YYYY
        "GioiTinh": 0,  # Nữ
        "MaSoThue": "5544332211",
        "SoDienThoaiDangKyDichVu": "0",  # Không thu thập
        "DiaChi": "300 Đường XYZ, Quận 5, TP. Đà Nẵng",
        "DiaChiKiemSoatTruyCap": "Khong thu thap duoc",
        "MaSoNhanDangThietBiDiDong": "Khong thu thap duoc",
        "SoTaiKhoan": "9998887776665554443",
        "LoaiTaiKhoan": 1,  # VND
        "TrangThaiHoatDongTaiKhoan": 1,  # Mở tại quầy
        "NgayMoTaiKhoan": "12/12/2023",
        "PhuongThucMoTaiKhoan": 1,
        "NgayXacThucTaiQuay": "12/12/2023",  # Định dạng DD/MM/YYYY
        "QuocTich": "VietNam"
    }
]
    # Không dùng query parameter, chỉ gửi qua header
    url = ENTRYPOINT_URL

    try:
        print(f"[📌] Header gửi đi: {headers}")
        print("[📌] Dữ liệu JSON gửi đi:")
        print(json.dumps(payload, indent=4, ensure_ascii=False))
        response = requests.post(url, headers=headers, json=payload, timeout=10)
        response.raise_for_status()
        print("[✔] Dữ liệu gửi thành công:", response.json())
    except requests.RequestException as e:
        print(f"[❌] Lỗi khi gửi dữ liệu: {e}")
        if e.response is not None:
            print(f"[❌] Chi tiết lỗi từ server: {e.response.text}")

# Chạy test
if __name__ == "__main__":
    send_simo_001_data()
