import requests
import json
import base64

# Thông tin API UAT
USERNAME = "simo-busanhcm"
PASSWORD = "simo660"
CONSUMER_KEY = "V2sF9dfIfbqXAkBfyauNz9WTJQoa"
CONSUMER_SECRET = "lnr90QpFPfClcm1chY5wijrLH08a"
TOKEN_URL = "https://mgsimotest.sbv.gov.vn/token"
ENTRYPOINT_URL = "https://mgsimotest.sbv.gov.vn/simo/tktt/1.0/upload-bao-cao-danh-sach-tktt-api"

# Hàm lấy token
def get_sbv_token():
    try:
        auth_string = f"{CONSUMER_KEY}:{CONSUMER_SECRET}"
        auth_base64 = base64.b64encode(auth_string.encode("utf-8")).decode("utf-8")
        headers = {
            "Authorization": f"Basic {auth_base64}",
            "Content-Type": "application/x-www-form-urlencoded"
        }
        data = {
            "grant_type": "password",
            "username": USERNAME,
            "password": PASSWORD
        }
        response = requests.post(TOKEN_URL, headers=headers, data=data, timeout=10)
        response.raise_for_status()
        return response.json().get("access_token")
    except requests.RequestException as e:
        print(f"[❌] Lỗi khi lấy token: {e}")
        return None

# Hàm gửi dữ liệu TKTT
def send_simo_001_data():
    token = get_sbv_token()
    if not token:
        print("[❌] Không thể lấy token, dừng chương trình.")
        return

    # Điền cứng maYeuCau và kyBaoCao trong header
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "maYeuCau": "TKTT_032024",
        "kyBaoCao": "03/2024"
    }
    
    payload = [
    {
        "Cif": "540101111800006",
        "SoID": "385353065",
        "LoaiID": 1,
        "TenKhachHang": "test2",
        "NgaySinh": "01/01/1954",
        "GioiTinh": 0,
        "MaSoThue": "8234631220",
        "SoDienThoaiDangKyDichVu": "03203703963",
        "DiaChi": "Addr test2",
        "DiaChiKiemSoatTruyCap": "Khong thu thap duoc",
        "MaSoNhanDangThietBiDiDong": "Khong thu thap duoc",
        "SoTaiKhoan": "132201201000149",
        "LoaiTaiKhoan": 2,
        "TrangThaiHoatDongTaiKhoan": 1,
        "NgayMoTaiKhoan": "02/02/2018",
        "PhuongThucMoTaiKhoan": 1,
        "NgayXacThucTaiQuay": "02/02/2018",
        "QuocTich": "VietNam"
    },
    {
        "Cif": "590610111600017",
        "SoID": "023785620",
        "LoaiID": 1,
        "TenKhachHang": "test3",
        "NgaySinh": "10/06/1959",
        "GioiTinh": 1,
        "MaSoThue": "8006458834",
        "SoDienThoaiDangKyDichVu": "0903809454",
        "DiaChi": "Addr test3",
        "DiaChiKiemSoatTruyCap": "Khong thu thap duoc",
        "MaSoNhanDangThietBiDiDong": "Khong thu thap duoc",
        "SoTaiKhoan": "132201201000024",
        "LoaiTaiKhoan": 2,
        "TrangThaiHoatDongTaiKhoan": 1,
        "NgayMoTaiKhoan": "30/08/2016",
        "PhuongThucMoTaiKhoan": 1,
        "NgayXacThucTaiQuay": "30/08/2016",
        "QuocTich": "VietNam"
    },
    {
        "Cif": "610827211700014",
        "SoID": "020309851",
        "LoaiID": 1,
        "TenKhachHang": "test4",
        "NgaySinh": "27/08/1961",
        "GioiTinh": 0,
        "MaSoThue": "8003736995",
        "SoDienThoaiDangKyDichVu": "0903334865",
        "DiaChi": "Addr test4",
        "DiaChiKiemSoatTruyCap": "Khong thu thap duoc",
        "MaSoNhanDangThietBiDiDong": "Khong thu thap duoc",
        "SoTaiKhoan": "132201201000138",
        "LoaiTaiKhoan": 2,
        "TrangThaiHoatDongTaiKhoan": 1,
        "NgayMoTaiKhoan": "10/10/2017",
        "PhuongThucMoTaiKhoan": 1,
        "NgayXacThucTaiQuay": "10/10/2017",
        "QuocTich": "VietNam"
    },
    {
        "Cif": "680101211700010",
        "SoID": "362338973",
        "LoaiID": 1,
        "TenKhachHang": "test5",
        "NgaySinh": "01/01/1968",
        "GioiTinh": 0,
        "SoDienThoaiDangKyDichVu": "0384060090",
        "DiaChi": "Addr test5",
        "DiaChiKiemSoatTruyCap": "Khong thu thap duoc",
        "MaSoNhanDangThietBiDiDong": "Khong thu thap duoc",
        "SoTaiKhoan": "132201100000115",
        "LoaiTaiKhoan": 1,
        "TrangThaiHoatDongTaiKhoan": 1,
        "NgayMoTaiKhoan": "15/06/2017",
        "PhuongThucMoTaiKhoan": 1,
        "NgayXacThucTaiQuay": "15/06/2017",
        "QuocTich": "VietNam"
    },
    {
        "Cif": "680101211700010",
        "SoID": "362338973",
        "LoaiID": 1,
        "TenKhachHang": "test6",
        "NgaySinh": "01/01/1968",
        "GioiTinh": 0,
        "SoDienThoaiDangKyDichVu": "0384060090",
        "DiaChi": "Addr test6",
        "DiaChiKiemSoatTruyCap": "Khong thu thap duoc",
        "MaSoNhanDangThietBiDiDong": "Khong thu thap duoc",
        "SoTaiKhoan": "132201201000128",
        "LoaiTaiKhoan": 2,
        "TrangThaiHoatDongTaiKhoan": 1,
        "NgayMoTaiKhoan": "15/06/2017",
        "PhuongThucMoTaiKhoan": 1,
        "NgayXacThucTaiQuay": "15/06/2017",
        "QuocTich": "VietNam"
    }
]



    # Không dùng query parameter, chỉ gửi qua header
    url = ENTRYPOINT_URL

    try:
        print(f"[📌] Header gửi đi: {headers}")
        print("[📌] Dữ liệu JSON gửi đi:")
        print(json.dumps(payload, indent=4, ensure_ascii=False))
        response = requests.post(url, headers=headers, json=payload, timeout=10)
        response.raise_for_status()
        print("[✔] Dữ liệu gửi thành công:", response.json())
    except requests.RequestException as e:
        print(f"[❌] Lỗi khi gửi dữ liệu: {e}")
        if e.response is not None:
            print(f"[❌] Chi tiết lỗi từ server: {e.response.text}")

# Chạy test
if __name__ == "__main__":
    send_simo_001_data()
