import requests
import json
import base64
import pyodbc
from datetime import datetime

# Thông tin API UAT
USERNAME = "simo-busanhcm"
PASSWORD = "simo660"
CONSUMER_KEY = "V2sF9dfIfbqXAkBfyauNz9WTJQoa"
CONSUMER_SECRET = "lnr90QpFPfClcm1chY5wijrLH08a"
TOKEN_URL = "https://mgsimotest.sbv.gov.vn/token"
ENTRYPOINT_URL = "https://mgsimotest.sbv.gov.vn/simo/tktt/1.0/upload-bao-cao-danh-sach-tktt-api"

# Thông tin kết nối database (MS SQL Server)
DB_CONFIG = {
    "server": "10.8.103.21",
    "user": "sa",
    "password": "q",
    "database": "simo"  
}

# Hàm lấy token
def get_sbv_token():
    try:
        auth_string = f"{CONSUMER_KEY}:{CONSUMER_SECRET}"
        auth_base64 = base64.b64encode(auth_string.encode("utf-8")).decode("utf-8")
        headers = {
            "Authorization": f"Basic {auth_base64}",
            "Content-Type": "application/x-www-form-urlencoded"
        }
        data = {
            "grant_type": "password",
            "username": USERNAME,
            "password": PASSWORD
        }
        response = requests.post(TOKEN_URL, headers=headers, data=data, timeout=10)
        response.raise_for_status()
        return response.json().get("access_token")
    except requests.RequestException as e:
        print(f"[❌] Lỗi khi lấy token: {e}")
        return None

# Hàm lấy dữ liệu từ database dựa trên danh sách CIF
def get_data_from_db(cif_list=None):
    try:
        # Kết nối database MS SQL Server
        conn_str = (
            f"DRIVER={{ODBC Driver 17 for SQL Server}};"
            f"SERVER={DB_CONFIG['server']};"
            f"DATABASE={DB_CONFIG['database']};"
            f"UID={DB_CONFIG['user']};"
            f"PWD={DB_CONFIG['password']}"
        )
        connection = pyodbc.connect(conn_str)
        cursor = connection.cursor()

        # Nếu không nhập CIF, lấy tất cả dữ liệu trong tháng hiện tại
        if not cif_list:
            current_date = datetime.now()
            current_month = current_date.month
            current_year = current_date.year

            query = """
            SELECT SoCIF, SoID, LoaiID, TenKhachHang, NgaySinh, GioiTinh, QuocTich, MaSoThue, 
                   SoDienThoaiDangKyDichVu, DiaChi, DiaChiKiemSoatTruyCap, MaSoNhanDangThietBiDiDong, 
                   SoTaiKhoan, LoaiTaiKhoan, TrangThaiHoatDongTaiKhoan, NgayMoTaiKhoan, 
                   PhuongThucMoTaiKhoan, NgayXacThucTaiQuay, CreatedAt
            FROM DanhSachTKTT
            WHERE MONTH(CreatedAt) = ? AND YEAR(CreatedAt) = ?
            """
            cursor.execute(query, (current_month, current_year))
        else:
            # Nếu có CIF, lọc theo danh sách CIF
            cif_tuple = tuple(cif_list)
            placeholders = ','.join('?' * len(cif_tuple))
            query = f"""
            SELECT SoCIF, SoID, LoaiID, TenKhachHang, NgaySinh, GioiTinh, QuocTich, MaSoThue, 
                   SoDienThoaiDangKyDichVu, DiaChi, DiaChiKiemSoatTruyCap, MaSoNhanDangThietBiDiDong, 
                   SoTaiKhoan, LoaiTaiKhoan, TrangThaiHoatDongTaiKhoan, NgayMoTaiKhoan, 
                   PhuongThucMoTaiKhoan, NgayXacThucTaiQuay, CreatedAt
            FROM DanhSachTKTT
            WHERE SoCIF IN ({placeholders})
            """
            cursor.execute(query, cif_tuple)

        rows = cursor.fetchall()
        print(f"[ℹ] Số bản ghi tìm thấy trong database: {len(rows)}")
        for row in rows:
            print(f"[ℹ] Bản ghi từ DB - SoCIF: {row[0]}, MaSoThue: {row[7]}")

        # Chuyển dữ liệu thành danh sách payload
        payload = []
        for row in rows:
            # Tạo dictionary cơ bản không bao gồm MaSoThue
            record = {
                "Cif": row[0],
                "SoID": row[1],
                "LoaiID": row[2],
                "TenKhachHang": row[3],
                "NgaySinh": row[4],  # Đã ở định dạng DD/MM/YYYY
                "GioiTinh": row[5],
                "SoDienThoaiDangKyDichVu": row[8],
                "DiaChi": row[9],
                "DiaChiKiemSoatTruyCap": row[10],
                "MaSoNhanDangThietBiDiDong": row[11],
                "LoaiTaiKhoan": row[13],
                "TrangThaiHoatDongTaiKhoan": row[14],
                "NgayMoTaiKhoan": row[15],  # Đã ở định dạng DD/MM/YYYY
                "PhuongThucMoTaiKhoan": row[16],
                "NgayXacThucTaiQuay": row[17],  # Đã ở định dạng DD/MM/YYYY
                "QuocTich": row[6]
            }

            # Xử lý MaSoThue: chỉ thêm nếu hợp lệ
            ma_so_thue = str(row[7]) if row[7] is not None else "0"
            if ma_so_thue != "0" and len(ma_so_thue) in [10, 13]:
                record["MaSoThue"] = int(ma_so_thue)  # Chuyển thành số nếu hợp lệ
            # Nếu không hợp lệ, không thêm trường MaSoThue

            # Xử lý SoTaiKhoan: phải là số
            so_tai_khoan_raw = str(row[12]) if row[12] is not None else "0"
            try:
                so_tai_khoan = int(so_tai_khoan_raw)  # Ép thành số
            except ValueError:
                so_tai_khoan = 0  # Nếu không ép được thành số, trả về 0
            record["SoTaiKhoan"] = so_tai_khoan

            payload.append(record)
            print(f"[ℹ] Thêm bản ghi vào payload - SoCIF: {row[0]}, MaSoThue: {ma_so_thue}")

        cursor.close()
        connection.close()
        print(f"[ℹ] Số bản ghi trong payload: {len(payload)}")
        return payload

    except Exception as e:
        print(f"[❌] Lỗi khi lấy dữ liệu từ database: {e}")
        return []

# Hàm gửi dữ liệu TKTT
def send_simo_001_data(cif_list=None):
    token = get_sbv_token()
    if not token:
        print("[❌] Không thể lấy token, dừng chương trình.")
        return

    # Điền cứng maYeuCau và kyBaoCao trong header
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "maYeuCau": "simo001_TKTT_032024",
        "kyBaoCao": "03/2024"
    }

    # Lấy dữ liệu từ database dựa trên CIF (nếu có) hoặc toàn bộ tháng hiện tại
    payload = get_data_from_db(cif_list)

    if not payload:
        print("[❌] Không có dữ liệu nào để gửi.")
        return

    url = ENTRYPOINT_URL

    try:
        print(f"[📌] Header gửi đi: {headers}")
        print("[📌] Dữ liệu JSON gửi đi:")
        print(json.dumps(payload, indent=4, ensure_ascii=False))
        response = requests.post(url, headers=headers, json=payload, timeout=10)
        response.raise_for_status()
        print("[✔] Dữ liệu gửi thành công:", response.json())
    except requests.RequestException as e:
        print(f"[❌] Lỗi khi gửi dữ liệu: {e}")
        if e.response is not None:
            print(f"[❌] Chi tiết lỗi từ server: {e.response.text}")

# Hàm chính để chạy chương trình
def main():
    # Nhập CIF từ người dùng
    cif_input = input("Nhập số CIF (cách nhau bởi dấu phẩy nếu nhiều CIF, để trống để gửi tất cả): ").strip()
    
    if cif_input:
        # Tách danh sách CIF và loại bỏ khoảng trắng
        cif_list = [cif.strip() for cif in cif_input.split(",") if cif.strip()]
        if cif_list:
            print(f"[ℹ] Gửi dữ liệu cho các CIF: {cif_list}")
            send_simo_001_data(cif_list)
        else:
            print("[❌] Danh sách CIF không hợp lệ.")
    else:
        # Nếu không nhập CIF, gửi tất cả dữ liệu trong tháng hiện tại
        print("[ℹ] Không nhập CIF, gửi tất cả dữ liệu trong tháng hiện tại.")
        send_simo_001_data()

# Chạy chương trình
if __name__ == "__main__":
    main()